function afficherPopup() {
    document.getElementById('overlay').style.display = 'block';
    document.getElementById('popup').style.display = 'block';
}

function cacherPopup() {
    document.getElementById('overlay').style.display = 'none';
    document.getElementById('popup').style.display = 'none';
}

function confirmerRefus() {
    cacherPopup();
}


function checkBoxClicked(event) {
    var checkboxId = event.target.id;
    var checkboxChecked = event.target.checked;

    console.log("Checkbox clicked: " + checkboxId);
    console.log("Checkbox checked state: " + checkboxChecked);
    
}


