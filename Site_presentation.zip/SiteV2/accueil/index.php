<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="header.css">
  <link href='https://fonts.googleapis.com/css?family=Inter' rel='stylesheet'>
  <link rel="stylesheet" href="style.css">
  <title>Document</title>
</head>

<body>
  <header>
    <a href="">
        <img src="../asset/img/logo.png" alt="logo">
    </a>
    <div></div>
    <div id="headerEmptyDiv"></div>
    <div id="headerLinkContainer">
        <svg id="headerGlobeLang" width="62.05" height="31.45" viewBox="0 0 73 37" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M24.0777 11.6823C23.0402 5.3169 20.5931 0.847595 17.7453 0.847595C14.8974 0.847595 12.4503 5.3169 11.4128 11.6823H24.0777ZM10.8761 18.5252C10.8761 20.1077 10.962 21.626 11.1123 23.0872H24.3711C24.5214 21.626 24.6072 20.1077 24.6072 18.5252C24.6072 16.9428 24.5214 15.4245 24.3711 13.9633H11.1123C10.962 15.4245 10.8761 16.9428 10.8761 18.5252ZM34.1095 11.6823C32.0631 6.84231 27.9202 3.10007 22.8041 1.58892C24.55 3.99821 25.7521 7.6264 26.3818 11.6823H34.1095ZM12.6793 1.58892C7.57035 3.10007 3.42025 6.84231 1.38098 11.6823H9.10875C9.73127 7.6264 10.9334 3.99821 12.6793 1.58892ZM34.8751 13.9633H26.668C26.8182 15.4602 26.9041 16.9927 26.9041 18.5252C26.9041 20.0578 26.8182 21.5903 26.668 23.0872H34.868C35.2615 21.626 35.4834 20.1077 35.4834 18.5252C35.4834 16.9428 35.2615 15.4245 34.8751 13.9633ZM8.58641 18.5252C8.58641 16.9927 8.67228 15.4602 8.82254 13.9633H0.61536C0.228971 15.4245 0 16.9428 0 18.5252C0 20.1077 0.228971 21.626 0.61536 23.0872H8.81538C8.67228 21.5903 8.58641 20.0578 8.58641 18.5252ZM11.4128 25.3682C12.4503 31.7336 14.8974 36.2029 17.7453 36.2029C20.5931 36.2029 23.0402 31.7336 24.0777 25.3682H11.4128ZM22.8112 35.4616C27.9202 33.9504 32.0703 30.2082 34.1167 25.3682H26.3889C25.7592 29.4241 24.5571 33.0523 22.8112 35.4616ZM1.38098 25.3682C3.42741 30.2082 7.57035 33.9504 12.6864 35.4616C10.9405 33.0523 9.73842 29.4241 9.10875 25.3682H1.38098Z" fill="#F5F5F5"/>
            <path d="M59.7897 24.8752C60.4591 25.4615 61.5462 25.4615 62.2157 24.8752L72.4979 15.8689C73.1674 15.2825 73.1674 14.3303 72.4979 13.744C71.8285 13.1576 70.7414 13.1576 70.072 13.744L61 21.6901L51.928 13.7487C51.2586 13.1623 50.1715 13.1623 49.5021 13.7487C48.8326 14.335 48.8326 15.2872 49.5021 15.8736L59.7843 24.8799L59.7897 24.8752Z" fill="#F5F5F5"/>
        </svg>
        <h3><a href="">Messagerie</a></h3>
        <h3><a href="">Mes réservations</a></h3>
        <h3><a href="">Mon compte</a></h3>
    </div>
    <div>

    </div>
</header>
  <div class="slider-container slider1">
    <div class="barreRecherche">
      <h2>Trouvez votre logement idéal</h2>
      <div class="bar">
        <div class="gauche-bar">


          <svg width="29" height="39" viewBox="0 0 29 39" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path
              d="M12.8497 37.4203C2.01173 21.7084 0 20.0959 0 14.3216C0 6.41195 6.41195 0 14.3216 0C22.2312 0 28.6431 6.41195 28.6431 14.3216C28.6431 20.0959 26.6314 21.7084 15.7934 37.4203C15.0822 38.4477 13.5609 38.4476 12.8497 37.4203ZM14.3216 20.2889C17.6172 20.2889 20.2889 17.6172 20.2889 14.3216C20.2889 11.0259 17.6172 8.35424 14.3216 8.35424C11.0259 8.35424 8.35424 11.0259 8.35424 14.3216C8.35424 17.6172 11.0259 20.2889 14.3216 20.2889Z"
              fill="#1D4C77" />
          </svg>

          <input id="searchbar" type="text" placeholder="Rechercher une destination ...">
        </div>
        <a class="search" href="#">Rechercher</a>
      </div>

    </div>
      <div class="point">
        <span class="dot" ></span>
        <span class="dot" ></span>
        <span class="dot" ></span>
        <span class="dot" ></span>
      </div>
      
      <div class="slider" id="slider">
        <img src="test.jpg" alt="d">
        <img src="test1.jpg" alt="">
        <img src="test2.jpg" alt="">
        <img src="test3.jpg" alt="tets">
        <img src="test.jpg" alt="d">
        
      </div>
  </div>
  <div class="filter-container">
    <div id="gauche">
      <a class="button" href="#">
        <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" viewBox="0 0 25 25" fill="none">
          <path
            d="M23.827 0H1.17324C0.132319 0 -0.392925 1.26299 0.344624 2.00054L9.375 11.0323V21.0938C9.375 21.4761 9.56157 21.8345 9.87485 22.0538L13.7811 24.7872C14.5518 25.3267 15.625 24.7799 15.625 23.8271V11.0323L24.6556 2.00054C25.3916 1.26445 24.87 0 23.827 0Z"
            fill="#F5F5F5" />
        </svg>
        <p>Filtres</p>
      </a>
      <a class="button" href="#">
        <svg width="26" height="30" viewBox="0 0 26 30" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M8.43766 16.4192H6.15721C5.78094 16.4192 5.47307 16.1114 5.47307 15.7351V13.4546C5.47307 13.0784 5.78094 12.7705 6.15721 12.7705H8.43766C8.81393 12.7705 9.12179 13.0784 9.12179 13.4546V15.7351C9.12179 16.1114 8.81393 16.4192 8.43766 16.4192ZM14.5949 15.7351V13.4546C14.5949 13.0784 14.287 12.7705 13.9107 12.7705H11.6303C11.254 12.7705 10.9461 13.0784 10.9461 13.4546V15.7351C10.9461 16.1114 11.254 16.4192 11.6303 16.4192H13.9107C14.287 16.4192 14.5949 16.1114 14.5949 15.7351ZM20.0679 15.7351V13.4546C20.0679 13.0784 19.7601 12.7705 19.3838 12.7705H17.1034C16.7271 12.7705 16.4192 13.0784 16.4192 13.4546V15.7351C16.4192 16.1114 16.7271 16.4192 17.1034 16.4192H19.3838C19.7601 16.4192 20.0679 16.1114 20.0679 15.7351ZM14.5949 21.2082V18.9277C14.5949 18.5514 14.287 18.2436 13.9107 18.2436H11.6303C11.254 18.2436 10.9461 18.5514 10.9461 18.9277V21.2082C10.9461 21.5844 11.254 21.8923 11.6303 21.8923H13.9107C14.287 21.8923 14.5949 21.5844 14.5949 21.2082ZM9.12179 21.2082V18.9277C9.12179 18.5514 8.81393 18.2436 8.43766 18.2436H6.15721C5.78094 18.2436 5.47307 18.5514 5.47307 18.9277V21.2082C5.47307 21.5844 5.78094 21.8923 6.15721 21.8923H8.43766C8.81393 21.8923 9.12179 21.5844 9.12179 21.2082ZM20.0679 21.2082V18.9277C20.0679 18.5514 19.7601 18.2436 19.3838 18.2436H17.1034C16.7271 18.2436 16.4192 18.5514 16.4192 18.9277V21.2082C16.4192 21.5844 16.7271 21.8923 17.1034 21.8923H19.3838C19.7601 21.8923 20.0679 21.5844 20.0679 21.2082ZM25.541 6.38525V26.4532C25.541 27.964 24.3153 29.1897 22.8045 29.1897H2.73654C1.22574 29.1897 0 27.964 0 26.4532V6.38525C0 4.87446 1.22574 3.64872 2.73654 3.64872H5.47307V0.684134C5.47307 0.30786 5.78094 0 6.15721 0H8.43766C8.81393 0 9.12179 0.30786 9.12179 0.684134V3.64872H16.4192V0.684134C16.4192 0.30786 16.7271 0 17.1034 0H19.3838C19.7601 0 20.0679 0.30786 20.0679 0.684134V3.64872H22.8045C24.3153 3.64872 25.541 4.87446 25.541 6.38525ZM22.8045 26.1111V9.12179H2.73654V26.1111C2.73654 26.2993 2.89047 26.4532 3.0786 26.4532H22.4624C22.6505 26.4532 22.8045 26.2993 22.8045 26.1111Z"
            fill="#F5F5F5" />
        </svg>

        <p>Dates</p>
      </a>
    </div>
    <div id="slogan">
      <div id="ps">
        <p>Des logements pour tout les goûts </p>
      </div>
     
    </div>
    <div class="ajout_log">
        <a href="../ajout_log.php">
          <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M23.7768 9.92104H15.7411V1.88532C15.7411 0.899275 14.9414 0.0996094 13.9554 0.0996094H12.1696C11.1836 0.0996094 10.3839 0.899275 10.3839 1.88532V9.92104H2.34821C1.36217 9.92104 0.5625 10.7207 0.5625 11.7068V13.4925C0.5625 14.4785 1.36217 15.2782 2.34821 15.2782H10.3839V23.3139C10.3839 24.2999 11.1836 25.0996 12.1696 25.0996H13.9554C14.9414 25.0996 15.7411 24.2999 15.7411 23.3139V15.2782H23.7768C24.7628 15.2782 25.5625 14.4785 25.5625 13.4925V11.7068C25.5625 10.7207 24.7628 9.92104 23.7768 9.92104Z" fill="#F5F5F5"/>
          </svg>
          <p>Ajouter un logement</p>
        </a>
    </div>
    <div id="trier">
      <a class="button" id="trier" href="#">
        <svg width="24" height="13" viewBox="0 0 24 13" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M10.7897 11.7363C11.4591 12.3249 12.5462 12.3249 13.2157 11.7363L23.4979 2.69556C24.1674 2.10697 24.1674 1.1511 23.4979 0.562509C22.8285 -0.0260811 21.7414 -0.0260811 21.072 0.562509L12 8.53907L2.92804 0.567217C2.25862 -0.0213728 1.17148 -0.0213728 0.502064 0.567217C-0.167355 1.15581 -0.167355 2.11168 0.502064 2.70026L10.7843 11.741L10.7897 11.7363Z"
            fill="#F5F5F5" />
        </svg>
  
        <p>Trier</p>
      </a>
    </div>
    </div>

  <div class="box">

    <?php

          $dir = '../Logement';


          if (is_dir($dir)) {

              $files = scandir($dir);
              $nb_log=0;
              foreach ($files as $file) {
                  if ($file !== '.' && $file !== '..') { 
                      $filePath = $dir . '/' . $file;

                      if (file_exists($filePath)) {
                        $serializedData = file_get_contents($filePath);
                        $info = unserialize($serializedData);
                    
                            
                          $serializedDataPic = file_get_contents("../img_log/".$file);
                          $photo = unserialize($serializedDataPic);

                        ?>

                        <a href="<?php

                          $source = '../exe_log.php';
                          $destination ='../Page/' . $info["titre"].'.php';
                          $dest=explode(" ",$destination);


                          
                          copy($source, $dest[0].".php");
                        
                          echo('../' . $dest[0].".php");
                        ?>" class="maison">
                          <div id="triangle"></div>
                          <div class="etoile">
                            <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                              <path
                                d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
                                fill="white" />
                            </svg>
                            <p>5.0</p>
                    
                          </div>
                          <img src="../asset/test_img/<?php echo($photo["photo"]["name"][0]); ?>" withd="300" height="225" alt="img">
                    
                          <p class="ville"><?php  echo($info["ville"]);  ?>, <?php echo($info["dep"]); ?></p>
                          <p class="prix"><strong><?php  echo($info["prix"]."€");  ?></strong> par nuit</p>
                          <p class="date">11 - 25 sept.</p>
                      </a>

                      <?php


                        
                      }
                  }
                  $nb_log++;
              }
          }

    ?>


    <a href="../logement.html" class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
      <img src="../asset/img/appart1.jpg" height="225" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>600€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </a>



    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
      <img src="image3.png" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>120€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </div>
    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

    </div>
      <img src="image3.png" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>120€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </div>
    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
      <img src="image3.png" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>120€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </div>
    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
      <img src="image3.png" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>120€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </div>
    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
      <img src="image3.png" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>120€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </div>
    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
        <img src="image3.png" alt="img">
        <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
        <p class="prix"><strong>120€</strong> par nuit</p>
        <p class="date">11 - 25 sept.</p>
    </div>
    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
      <img src="image3.png" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>120€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </div>
    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
      <img src="image3.png" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>120€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </div>
    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
      <img src="image3.png" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>120€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </div>
    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
      <img src="image3.png" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>120€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </div>
    <div class="maison">
      <div id="triangle"></div>
      <div class="etoile">
        <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M7.5 0L9.18386 5.52786H14.6329L10.2245 8.94427L11.9084 14.4721L7.5 11.0557L3.09161 14.4721L4.77547 8.94427L0.367076 5.52786H5.81614L7.5 0Z"
            fill="white" />
        </svg>
        <p>5.0</p>

      </div>
      <img src="image3.png" alt="img">

      <p class="ville">Perros-Guirrec, Côtes-D’armor</p>
      <p class="prix"><strong>120€</strong> par nuit</p>
      <p class="date">11 - 25 sept.</p>
    </div>
  

  </div>
  <div class="more-container">
    <div id="plus">
        <p>Poursuivre la recherche des logements..</p>
        <div id="ps">
          <a href="#">Afficher plus</a>
        </div>
    </div>
    
      
  </div>
  <footer>
    <div>
        <div id="footerCercleLogo">
            <img src="../asset/img/logo.png" alt="logo">
        </div>
        <div id="footerText">
            <div>
                <h4>Nous contacter</h4>
                <address>1, Rue édouard Branly, 22300 Lannion</address><br>
                <a href="tel:+33296469300">02 96 46 93 00</a><br>
                <a href="mailto:iut-lannion.univ-rennes.fr">iut-lannion.univ-rennes.fr</a>
            </div>
            <div>
                <h4>Informations légales</h4>
                <a href="">Plan du site</a><br>
                <a href="">Mention légales</a><br>
                <a href="">Condition générales de ventes</a><br>
                <a href="">Données personnelles</a><br>
                <a href="">Gestion de cookies</a><br>
            </div>
        </div>
    </div>
    <div>
        <p>texte random</p>
        <p>Cpyright @ 2023 LoQuali.com</p>
        <p>Suivez-nous !</p>
    </div>
</footer>
<script>
    document.addEventListener("DOMContentLoaded", function () {
    var slider = document.querySelector(".slider1 .slider");
    var dots = document.querySelectorAll(".dot");
    var currentIndex = 0;
    var imageCount = 5;
    var animationInProgress = false;
    var intervalId;

    function animateSlider() {
        if (!animationInProgress) {
            animationInProgress = true;

            var translateValue = currentIndex * -100;

            slider.style.transition = "transform 3s ease-in-out";
            slider.style.transform = "translateX(" + translateValue + "%)";
            dots.forEach(function (dot, index) {
                dot.classList.remove("active");
                    if (index === currentIndex || (currentIndex === imageCount - 1 && index === 0)) {
                      dot.classList.add("active");
                    }
                
            });


            setTimeout(function () {
                animationInProgress = false;

                if (currentIndex === imageCount - 1) {
                    slider.style.transition = "none";
                    currentIndex = 0;
                    slider.style.transform = "translateX(0)";
                    setTimeout(function () {
                        slider.style.transition = "";
                    }, 0);
                } else {
                    currentIndex = (currentIndex + 1) % imageCount;
                }
            }, 3000);
        }
    }

    function dotClickHandler(index) {
        return function () {
            currentIndex = index;
            clearInterval(intervalId);
            animateSlider();
            setTimeout(function () {
                intervalId = setInterval(animateSlider, 2000);
            }, 2000);
        };
    }

    function dotDecthover(index){

    }

    dots.forEach(function (dot, index) {
        dot.addEventListener("click", dotClickHandler(index));
    });

    intervalId = setInterval(animateSlider, 2000);
});



</script>
</body>

</html>